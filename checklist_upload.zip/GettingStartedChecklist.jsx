﻿import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function GettingStartedChecklist({ hasGoogleLink, hasSentRequest }) {
  const [visitedQr, setVisitedQr] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(function() {
    setVisitedQr(localStorage.getItem('rb_visited_qr') === '1');
    setDismissed(localStorage.getItem('rb_getting_started_dismissed') === '1');
    setMounted(true);
  }, []);

  var items = [
    { label: 'Add your Google Review link', done: !!hasGoogleLink, href: '/dashboard/settings' },
    { label: 'Generate your QR code', done: visitedQr, href: '/dashboard/qr' },
    { label: 'Send your first review request', done: !!hasSentRequest, href: '/dashboard/customers' },
  ];
  var doneCount = items.filter(function(i) { return i.done; }).length;

  if (!mounted || dismissed || doneCount === items.length) return null;

  function handleDismiss() {
    localStorage.setItem('rb_getting_started_dismissed', '1');
    setDismissed(true);
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mb-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-sm font-bold text-gray-900">Getting Started</p>
          <p className="text-xs text-gray-400">{doneCount + ' of ' + items.length + ' done'}</p>
        </div>
        <button onClick={handleDismiss} className="text-gray-400 hover:text-gray-600 text-lg leading-none px-1" aria-label="Dismiss">
          {'\u00D7'}
        </button>
      </div>
      <div className="space-y-2">
        {items.map(function(item, idx) {
          return (
            <Link key={idx} href={item.href} className={"flex items-center gap-2.5 px-3 py-2.5 rounded-xl border transition-colors " + (item.done ? 'border-green-100 bg-green-50' : 'border-gray-100 hover:bg-gray-50')}>
              <span className={"w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 " + (item.done ? 'bg-green-500 text-white' : 'border-2 border-gray-300')}>
                {item.done ? '\u2713' : ''}
              </span>
              <span className={"text-sm " + (item.done ? 'text-gray-400 line-through' : 'text-gray-700 font-medium')}>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
